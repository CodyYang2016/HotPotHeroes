using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace sprint0Test.Interfaces
{
    public interface IController
    {
           void Update();
    }
}