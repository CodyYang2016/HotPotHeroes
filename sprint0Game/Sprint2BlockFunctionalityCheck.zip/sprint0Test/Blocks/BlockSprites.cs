using System.Drawing;
using System.Security.Principal;
using sprint0Test;

public class BlockSprites
{
    Rectangle tile = new Rectangle(984, 11, 16, 16);
    Rectangle black = new Rectangle(984, 27, 16, 16);
    Rectangle brick = new Rectangle(984, 45, 16, 16);
    Rectangle block = new Rectangle(1001, 11, 16, 16);
    Rectangle sand = new Rectangle(1001, 27, 16, 16);
    Rectangle ramp = new Rectangle(1001, 45, 16, 16);
    Rectangle fish = new Rectangle(1018, 11, 16, 16);
    Rectangle blue = new Rectangle(1018, 27, 16, 16);
    Rectangle dragon = new Rectangle(1035, 11, 16, 16);
    Rectangle stair = new Rectangle(1035, 27, 16, 16);

}