﻿using var game = new sprint0Test.Game1();
game.Run();
