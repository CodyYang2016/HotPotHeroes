using Microsoft.Xna.Framework;
using CSE3902;


namespace CSE3902 {


public interface IController
{
    void Update(GameTime gameTime);
}
}